<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<script type="text/javascript" src="assets/js/jquery.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap.js"></script>
</head>
<body background="img/bg.jpg">
	<div class="container">
	<form method="post" action="aksi_login.php">

		<div class="col-md-4 col-md-offset-4">
		<h3 class="text-center">Please Login Here</h3>
		<div class="form-group">
			<label for="username">Username</label>
			<input type="text" name="username" placeholder="Masukan Username" required="" class="form-control">
		</div>

		<div class="form-group">
			<label for="password">Password</label>
				<input type="password" name="password" placeholder="Masukan Password" required="" class="form-control">
		</div>

				<input type="submit" name="login" value="Login" class="btn btn-primary btn-block">

		<?php 
		if(isset($_GET['pesan'])){
			if($_GET['pesan'] == "gagal"){
				echo "<div style='margin-bottom:-55px' class='alert alert-danger' role='alert'>
				<span class='glyphicon glyphicon-warning-sign'></span>  Login Gagal !! Username dan Password Salah !!</div>";
			}
		}
		?>		
	</div>
	</form>
</div>
</body>
</html>