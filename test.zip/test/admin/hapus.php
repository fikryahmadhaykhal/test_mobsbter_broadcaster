<?php 
//koneksi database
include 'koneksi.php';

//menangkap data dari url
$id = $_GET['id'];

//hapus data
mysqli_query($koneksi,"delete from pelanggan where id='$id'");

//mengalihkan halaman
header("location:index.php");
 ?>