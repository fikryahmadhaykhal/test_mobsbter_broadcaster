<?php include 'header.php'; ?>
<title>MOBSTER</title>
<body>
	<div class="container">
	<h1>Data Pelanggan</h1>
	<br>
	<a href="tambah.php" class="btn btn-success">+Tambah Data</a>
	<br/>
	<br/>

	<table class="table table-bordered table-hover">
		<thead>
			<tr class="info">
				<td>Id</td>
				<td>Nama</td>
				<td>Email</td>
				<td>No. Whatsapp</td>
				<td>Aksi</td>
			</tr>
		</thead>
<?php include 'koneksi.php';
$data = mysqli_query($koneksi,"select * from pelanggan");
while($d = mysqli_fetch_array($data)) :?>
	<tr>
		<td><?php echo $d['id'];?></td>
		<td><?php echo $d['nama'];?></td>
		<td><?php echo $d['email'];?></td>
		<td><?php echo $d['nomor_whatsapp'];?></td>
		<td>
			<a href="edit.php?id=<?php echo $d['id']; ?>" class="btn btn-info">Edit</a>
			<a href="hapus.php?id=<?php echo $d['id']; ?>" class="btn btn-danger"onclick = "return confirmDialog()">Delete</a>
		</td>

	</tr>
<?php endwhile; ?>
	<script>
		function confirmDialog(){
			return confirm('Apakah Yakin Akan Menghapus Data ?')
		}

	</script>
	</table>
	<br>
		<h5> Catatan : Untuk Broadcast message ke Whatsapp seluruh pelanggan saya sudah mencoba browsing dan implementasikan tapi selalu gagal. Tetapi untuk fitur lainnya sudah berhasil. Semoga menjadi bahan pertimbangan dan saya yakin akan berusaha untuk lebih baik lagi.</h5>


	</div>
</body>
<?php include 'footer.php'; ?>