<?php include 'header.php'; ?>
<body>
	<div class="container">
		<h3>Tambah Pelanggan Baru</h3>
		<a href="index.php"><button type="button" class="btn btn-success">Back</button></a>
		<br></br>
		<form action="aksi_tambah.php" method="post">
			<table class="table table-bordered table-striped table-hover">
				<tr>
					<td>Id</td>
					<td><input type="text" name="id" class="form-control" placeholder="Contoh = P0001" required=""></td>
				</tr>
				
				<tr>
					<td>Nama</td>
					<td><input type="text" name="nama" class="form-control" placeholder="Masukkan Nama..." required=""></td>
				</tr>

				<tr>
					<td>Email</td>
					<td><input type="text" name="email" class="form-control" placeholder="Masukkan Email..." required=""></td>
				</tr>
				
				<tr>
					<td>No.Whatsapp</td>
					<td><input type="text" name="nomor_whatsapp" class="form-control" placeholder="Masukkan Nomor Whatsapp..." required=""></td>
				</tr>

				<tr>
					<td></td>
					<td><input type="submit" class="btn btn-info" value="Submit"></td>
				</tr>

			</table>
			
		</form>
	</div>
</body>
<?php include 'footer.php'; ?>