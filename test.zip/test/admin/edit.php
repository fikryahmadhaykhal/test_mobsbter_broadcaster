<?php include 'header.php'; ?>
<body>
	<div class="container">
		<div class="modal-header">
		<p><h3>Edit Pasien</h3></p>
		</div>

	<?php 
	include 'koneksi.php';
	$id = $_GET['id'];
	$data = mysqli_query($koneksi,"select * from pelanggan where id = '$id'");
	while($d = mysqli_fetch_array($data)) :?>

		<form method="post" action="aksi_update.php">
			<table class="table table-bordered table-striped table-hover">
				<tr>			
					<td>Nama</td>
					<td>
						<input type="hidden" name="id" value="<?php echo $d['id']; ?>">
						<input type="text" name="nama" value="<?php echo $d['nama']; ?>"  class="form-control">
					</td>
				</tr>

				<tr>
					<td>Email</td>
					<td><input type="text" name="email" value="<?php echo $d['email']; ?>"  class="form-control"></td>
				</tr>
				
				<tr>
					<td>No.Whatsapp</td>
					<td><input type="text" name="nomor_whatsapp" value="<?php echo $d['nomor_whatsapp']; ?>"  class="form-control"></td>
				</tr>
				
				<td></td>
					<td><input type="submit" value="Submit" class="btn btn-success"></td>
				</tr>
			</table>
		</form>

	<?php endwhile; ?>
	</div>
</body>
<?php include 'footer.php'; ?>