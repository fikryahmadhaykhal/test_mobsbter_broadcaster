<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>MOBSTER</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">
	<script type="text/javascript" src="../assets/js/jquery.js"></script>
	<script type="text/javascript" src="../assets/js/bootstrap.js"></script>
</head>
<body>
	<div class="container">
		<br>
		<nav class="navbar navbar-dark bg-success">
			<nav class="navbar-header">
				<a href="index.php" class="navbar-brand">HOME</a>
		</nav>
	<ul class="nav navbar-nav">
	</ul>
	</div>
</body>
