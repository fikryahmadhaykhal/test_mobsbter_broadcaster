<?php 
	include 'koneksi.php';

//menangkap data dari form
	$id = $_POST['id'];
	$nama = $_POST['nama'];
	$email = $_POST['email'];
	$nomor_whatsapp = $_POST['nomor_whatsapp'];

//menambahkan data ke database
	mysqli_query($koneksi,"insert into pelanggan values('$id','$nama','$email','$nomor_whatsapp')");

//kembali ke index pasien
	header("location:index.php");
 ?>